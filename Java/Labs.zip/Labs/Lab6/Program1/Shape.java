package P1;
abstract public class Shape{
    public String shape;
    public String getShape(){
        return "";
    }
    abstract public double getArea();
} 