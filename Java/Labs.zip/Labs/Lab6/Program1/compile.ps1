javac -d . Shape.java Rectangle.java Circle.java Driver1.java
java Driver1

