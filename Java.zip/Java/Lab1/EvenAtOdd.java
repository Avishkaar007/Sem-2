public class EvenAtOdd {
    public static void main(String [] args){
        int arr[]= {2,3,5,7,10,1};
        int sum=0;
        
        for(int a=0;a<arr.length;a+=2){
            if ((arr[a]%2)==0){}
        }

    }
}